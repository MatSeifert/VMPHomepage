<?php
/**
 * Created by JetBrains PhpStorm.
 * User: blorenz
 * Date: 05.08.12
 * Time: 08:50
 * To change this template use File | Settings | File Templates.
 */
namespace Terrific\Module\SidebarWidget\Twig\Extension {
    use Twig_Extension;
    use Twig_Filter_Method;
    use devmx\TSWebViewer\TSWebViewer;
    use devmx\TSWebViewer\RenderOptions;
    use Symfony\Component\Finder\Finder;

    /**
     *s
     */
    class SidebarExtension extends Twig_Extension
    {
        private $webPath = null;


        public function getTeamspeak()
        {
            $viewer = new TSWebViewer('www.the-forgotten.de', '10011', '9987', 'tfg-site_query', 'G5ltKC4c');
            $viewerOptions = new RenderOptions();
            $viewerOptions->connectLink(true);
            $viewerOptions->imgPath(str_replace($_SERVER["DOCUMENT_ROOT"], "", realpath($this->webPath . "/img/bundles/TSViewer")));
            return $viewer->renderServer($viewerOptions);
        }

        /**
         *
         */
        public function getScreenshots($count, $categorized = false)
        {
            $f = new Finder();
            $f->files()->in($this->webPath . "/media/screenshots")->sort(function(\SplFileInfo $a, \SplFileInfo $b)
            {
                switch (true) {
                    case ($a->getMTime() > $b->getMTime()):
                        return -1;

                    case ($a->getMTime() < $b->getMTime()):
                        return 1;

                    default:
                        return 0;
                }
            });
            $ret = array();

            if ($categorized) {
                $lastCat = null;
                foreach ($f as $file) {
                    if (count($ret) == $count) {
                        break;
                    }

                    $cat = date("M Y", $file->getMTime());

                    if (!isset($ret[$cat])) {
                        $ret[$cat] = array();
                    }

                    $ret[$cat][] = str_replace($_SERVER["DOCUMENT_ROOT"], "", $file->getRealpath());
                }

            } else {
                foreach ($f as $file) {
                    if (count($ret) == $count) {
                        break;
                    }
                    $ret[] = str_replace($_SERVER["DOCUMENT_ROOT"], "", $file->getRealpath());
                }
            }

            return $ret;
        }


        /**
         * Returns the name of the extension.
         *
         * @return string The extension name
         */
        function getName()
        {
            return "sidebar_extension";
        }

        /**
         * @return array
         */
        public function getFunctions()
        {
            return array(
                'screens' => new \Twig_Function_Method($this, 'getScreenshots'),
                'teamspeak' => new \Twig_Function_Method($this, 'getTeamspeak', array('is_safe' => array('html')))
            );
        }

        function __construct()
        {
            $this->webPath = __DIR__ . "/../../../../../../web";
        }
    }
}

