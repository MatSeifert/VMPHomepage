(function ($) {

    "use strict";

    /**
     * Teamspeak Skin implementation for module SidebarWidget.
     *
     * @author Terrific Composer
     * @namespace Tc.Module.SidebarWidget
     * @class Teamspeak
     * @extends Tc.Module
     * @constructor
     */
    Tc.Module.SidebarWidget.Teamspeak = function (parent) {
        /**
         * override the appropriate methods from the decorated module (ie. this.get = function()).
         * the former/original method may be called via parent.<method>()
         */
        this.on = function (callback) {
            // calling parent method
            parent.on(callback);
        };

        this.after = function () {
            // calling parent method
            parent.after();
        };
    };
})(Tc.$);
