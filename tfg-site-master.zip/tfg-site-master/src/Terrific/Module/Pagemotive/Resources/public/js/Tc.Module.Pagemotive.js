(function ($) {

    "use strict";

    /**
     * Pagemotive module implementation.
     *
     * @author Terrific Composer
     * @namespace Tc.Module
     * @class Pagemotive
     * @extends Tc.Module
     */
    Tc.Module.Pagemotive = Tc.Module.extend({

        /**
         * Initializes the Pagemotive module.
         *
         * @method init
         * @return {void}
         * @constructor
         * @param {jQuery} $ctx the jquery context
         * @param {Sandbox} sandbox the sandbox to get the resources from
         * @param {Number} id the unique module id
         */
        init:function ($ctx, sandbox, id) {
            // call base constructor
            this._super($ctx, sandbox, id);
        },

        /**
         * Hook function to do all of your module stuff.
         *
         * @method on
         * @param {Function} callback function
         * @return void
         */
        on:function (callback) {
            callback();

            this.imageList = $('img', this.$ctx);
            this.count = 1;
            this.currentSelected = $('img.first-child', this.$ctx);

            setInterval($.proxy(this.changePicture, this), 5000);
        },

        /**
         *
         */
        changePicture:function () {
            this.count = (this.count + 1) % (this.imageList.size());

            var tmp = this.imageList.eq(this.count);

            if (tmp.attr('src') === this.currentSelected.attr("src")) {
                this.changePicture();
                return;
            }

            this.currentSelected.stop().animate({
                'opacity':0
            });

            tmp.stop().css({
                'opacity':0,
                'display':'block'
            }).animate({
                    'opacity':1
                });

            this.currentSelected = tmp;
        },

        getRandom:function (min, max) {
            if (min > max) {
                return -1;
            }

            if (min == max) {
                return min;
            }

            var r;

            do {
                r = Math.random();
            }
            while (r == 1.0);

            return min + parseInt(r * (max - min + 1));
        },

        /**
         * Hook function to trigger your events.
         *
         * @method after
         * @return void
         */
        after:function () {

        }
    });
})
    (Tc.$);
