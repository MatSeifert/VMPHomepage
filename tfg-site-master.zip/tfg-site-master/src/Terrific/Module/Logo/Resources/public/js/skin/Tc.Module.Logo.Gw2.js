(function ($) {
    "use strict";

    /**
     * Gw2 Skin implementation for module Logo.
     *
     * @author Terrific Composer
     * @namespace Tc.Module.Logo
     * @class Gw2
     * @extends Tc.Module
     * @constructor
     */
    Tc.Module.Logo.Gw2 = function (parent) {
        /**
         * override the appropriate methods from the decorated module (ie. this.get = function()).
         * the former/original method may be called via parent.<method>()
         */
        this.on = function (callback) {
            // calling parent method
            parent.on(callback);
        };

        this.after = function () {
            // calling parent method
            parent.after();
        };
    };
})(Tc.$);
