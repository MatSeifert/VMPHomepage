(function ($) {

    "use strict";

    /**
     * Layout module implementation.
     *
     * @author Terrific Composer
     * @namespace Tc.Module
     * @class Layout
     * @extends Tc.Module
     */
    Tc.Module.Layout = Tc.Module.extend({
        /**
         * Initializes the Layout module.
         *
         * @method init
         * @return {void}
         * @constructor
         * @param {jQuery} $ctx the jquery context
         * @param {Sandbox} sandbox the sandbox to get the resources from
         * @param {Number} id the unique module id
         */
        init:function ($ctx, sandbox, id) {
            // call base constructor
            this._super($ctx, sandbox, id);

            $.fancybox.defaults = $.extend($.fancybox.defaults, {
                'maxWidth' :1200,
                'maxHeight':675,
                'fitToView':true,
                'loop'     :false
            });


            // Fancybox
            $('a[rel="overlay"].gallery', this.$ctx).fancybox({
                'arrows'  :true,
                'closeBtn':false,
                'helpers' :{
                    'buttons':{}
                }
            });

            $('a[rel="overlay"]:not(.gallery)', this.$ctx).fancybox({
                'arrows':false
            });
        },

        /**
         * Hook function to do all of your module stuff.
         *
         * @method on
         * @param {Function} callback function
         * @return void
         */
        on:function (callback) {
            callback();
        },

        /**
         * Hook function to trigger your events.
         *
         * @method after
         * @return void
         */
        after:function () {

        }
    });
})(Tc.$);
