<?php

/*
 * This file is part of the Terrific Composer Bundle.
 *
 * (c) Remo Brunschwiler <remo@terrifically.org>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Terrific\Module\Layout;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TerrificModuleLayout extends Bundle
{
}
