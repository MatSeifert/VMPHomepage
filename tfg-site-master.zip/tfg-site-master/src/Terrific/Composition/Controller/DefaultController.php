<?php

namespace Terrific\Composition\Controller {
    use Symfony\Bundle\FrameworkBundle\Controller\Controller;
    use Terrific\ComposerBundle\Annotation\Composer;
    use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
    use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
    use Doctrine\ORM\EntityManager;


    /**
     *
     */
    class DefaultController extends Controller
    {


        /**
         * @Composer("Home")
         * @Route("/", name="home")
         * @Template()
         */
        public function indexAction()
        {
            return array();
        }


        /**
         * @Composer("Impressum")
         * @Route("/Impressum", name="impressum")
         * @Template()
         */
        public function impressumAction()
        {
            return array();
        }

        /**
         * @Composer("Screens")
         * @Route("/Screenshots", name="screens")
         * @Template()
         */
        public function screensAction()
        {
            return array();
        }

        /**
         * @Composer("About")
         * @Route("/About", name="about")
         * @Template()
         */
        public function aboutAction()
        {
            return array();
        }
    }
}
