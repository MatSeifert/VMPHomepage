<?php

namespace Terrific\Composition;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TerrificComposition extends Bundle
{
}
